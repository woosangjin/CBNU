
"use strict";

let testmsg = require('./testmsg.js');

module.exports = {
  testmsg: testmsg,
};
