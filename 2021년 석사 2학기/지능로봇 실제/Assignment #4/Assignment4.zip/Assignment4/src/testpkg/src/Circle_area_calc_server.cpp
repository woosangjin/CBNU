#include "ros/ros.h"    /*ros*/
#include "testpkg/testsrv.h"    /*custom srv*/
#include <vector>   /*vector*/
#include <stdlib.h> /*srand, rand*/
#include <cmath>    /*MATH*/

std::vector<double> storedVector(5);   ///double타입의 vector배열 생성, 사이즈 : 5

float val;  ///area 저장변수

bool area(testpkg::testsrv::Request &req,testpkg::testsrv::Response &res)   
{
    val = req.radius.at(4) * req.radius.at(4) * M_PI;   ///넓이 계산   
    storedVector.push_back(val);    ///vector배열의 끝에 원소삽입
    storedVector.erase(storedVector.begin());   ///vector배열의 첫번째 원소제거
    res.Area = storedVector;    ///vector배열 전달

    ROS_INFO("------server------"); ///출력부분            
    ROS_INFO("area : [%f]",(float)res.Area.at(4));  ///출력부분

    return true;
}

int main(int argc, char **argv)
{
    ros::init(argc, argv, "Calc_server");   ///노드를 마스터에 등록
    ros::NodeHandle n;  ///노드 핸들러 생성
    ///서비스 server생성 srv name : Random_radius_calc req받을때 실행할 함수 : area
    ros::ServiceServer service = n.advertiseService("Random_radius_calc",area);

    ROS_INFO("Ready to calc."); ///출력부분
    ros::spin();    ///반복

    return 0;
}
