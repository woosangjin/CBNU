#include "ros/ros.h"    /*ros*/
#include "testpkg/testsrv.h"    /*custom srv*/
#include <stdio.h>  /*printf,scanf,puts,NULL*/
#include <stdlib.h> /*srand,rand*/
#include <time.h>   /*time*/
#include <vector>    /*vector*/
#include "testpkg/testmsg.h"    /*custom msg*/

std::vector<int64_t> storedVector(5);   ///int64_t타입의 vector배열 생성, 사이즈 : 5
std::vector<double> storedVEctor2(5);   ///double타입의 vector배열 생성, 사이즈 : 5

int main(int argc, char **argv)
{
    int val=0;  ///난수 저장변수

    ros::init(argc, argv, "Random_radius"); ///노드를 마스터에 등록

    ros::NodeHandle n;  ///노드 핸들러 생성
    ///서비스 client생성, custom srv -> test srv, srv name : Random_radius_calc
    ros::ServiceClient client = n.serviceClient <testpkg::testsrv>("Random_radius_calc");
    ///publisher생성, 타입 : custommsg, topic명 :calc_result_pub, 버퍼사이즈 : 1
    ros::Publisher chatter_pub = n.advertise<testpkg::testmsg>("calc_result_pub",1);
 
    testpkg::testsrv srv;   ///srv 객체생성

    ros::Rate loop_rate(1); /// 1초주기

    srand(time(NULL));  ///rand 함수에 사용될 수를 초기화 진짜 난수를 위한부분
    while(ros::ok)  ///반복문
    {
        testpkg::testmsg pub_data;  ///msg 객체생성

        val = rand() % 10 + 1;  ///나머지 연산으로 계산하여 1~10생성
        /// vector배열은 큐의 형태
        storedVector.push_back(val);    ///vector배열의 끝에 원소삽입
        storedVector.erase(storedVector.begin());   ///vector배열의 첫번째 원소제거
        srv.request.radius = storedVector;  ///vector배열 전달

        ROS_INFO("------client------"); ///출력부분

        if(client.call(srv))    ///srv호출
        {
            ROS_INFO("Radius :%d",val); ///radius 출력

            pub_data.radius = storedVector; ///radius값 custom msg에저장
            pub_data.area = srv.response.Area;  ///area값 custom msg에저장
            chatter_pub.publish(pub_data);  ///publish
        }
        else
        {
            ROS_ERROR("Failed to call service");    ///예외처리
            return 1;
        }
        loop_rate.sleep();  ///loop주기에따른 sleep
    }
    return 0;
}

