#include "ros/ros.h"    /*ros*/
#include "std_msgs/Int64.h" /*Int64*/
#include <stdio.h>  /*printf,scanf,puts,NULL*/
#include <stdlib.h> /*srand,rand*/
#include <time.h>   /*time*/

int main(int argc, char **argv)
{
    int val=0;  ///난수 저장변수

    ros::init(argc, argv, "A"); ///노드를 마스터에 등록
    ros::NodeHandle n;  ///노드 핸들러 생성
    ///Publisher생성 타입: int64, topic명 : Ramdom_1_10, 버퍼사이즈 : 1000    
    ros::Publisher chatter_pub = n.advertise<std_msgs::Int64>("Random_1_10",1000);  

    ros::Rate loop_rate(2); /// hz

    srand(time(NULL));  ///rand 함수에 사용될 수를 초기화 진짜 난수를 위한부분

    while(ros::ok()) ///반복문
    {
        std_msgs::Int64 msg;    ///int64타입 msg변수 생성

        val = rand() % 10 + 1;  ///나머지 연산으로 계산하여 1~10생성
        msg.data = val; ///계산된 값을 msg변수에 저장

        ROS_INFO("[TX] Random Number = %d", msg.data);  ///msg변수 출력

        chatter_pub.publish(msg);   ///publish부분
 
        ros::spinOnce();    ///while루프 안이므로 spinOnce사용

        loop_rate.sleep();  ///루프주기에 따른 sleep
    }
    return 0;
}


