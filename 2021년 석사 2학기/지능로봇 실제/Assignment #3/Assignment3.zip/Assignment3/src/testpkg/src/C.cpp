#include "ros/ros.h"    /*ros*/
#include "std_msgs/Int64.h" /*Int64*/

/*Subscribe된 값을 저장할 변수*/
int A;  
int B;
/*A노드로부터 Subscribe한 값을 저장하는 함수*/
void chatterCallback(const std_msgs::Int64::ConstPtr& msg)  
{
    ROS_INFO("[RX] A: [%d]", msg->data);    ///Subscribe한 값을 출력
    A = msg->data;  ///subscribe한 값을 변수 A에저장
}

/*B노드로부터 Subscribe한 값을 저장하는 함수*/
void chatterCallback2(const std_msgs::Int64::ConstPtr& msg2)
{
    ROS_INFO("[RX] B: [%d]", msg2->data);    ///Subscribe한 값을 출력
    B = msg2->data;  ///subscribe한 값을 변수 B에저장
}
/*2개의 노드를 subscribe하여 수집한 값을 더하여 publish*/
int main(int argc, char **argv)
{
    ros::init(argc, argv, "C"); ///노드를 마스터에 등록
    ros::NodeHandle n;  ///노드 핸들러 생성
    ros::MultiThreadedSpinner(2);   ///MultiThread를 위한 부분 총 2개의 쓰레드
    ///Subscriber 생성 Subscribe할 topic명 : Ramdom_1_10, 버퍼사이즈 : 1000, callback함수 : chattercallback
    ros::Subscriber sub = n.subscribe("Random_1_10", 1000, chatterCallback);
    ///Subscriber 생성 Subscribe할 topic명 : Ramdom_11_20, 버퍼사이즈 : 1000, callback함수 : chattercallback2
    ros::Subscriber sub2 = n.subscribe("Random_11_20", 1000, chatterCallback2);
    ///Publisher 생성 타입: int64, topic명 : SUM, 버퍼사이즈 : 1000
    ros::Publisher sum_pub = n.advertise<std_msgs::Int64>("SUM",1000);

    ros::Rate loop_rate(2); /// hz

    while(ros::ok()) ///반복문
    {
        std_msgs::Int64 msg;    ///int64타입 msg변수 생성

        msg.data = A+B; ///Subscribe로 받은 A,B의 합을 저장
        ROS_INFO("[TX] SUM : [%d]",msg.data );  ///A,B의 합을 출력
        sum_pub.publish(msg);   ///publish부분

        ros::spinOnce();    ///while루프 안이므로 spinOnce사용

        loop_rate.sleep();  ///루프주기에 따른 sleep       
    }
       return 0;
}

