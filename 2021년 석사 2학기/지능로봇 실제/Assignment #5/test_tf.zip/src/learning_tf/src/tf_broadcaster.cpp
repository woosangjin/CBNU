#include <ros/ros.h>    /*ros*/
#include <tf/transform_broadcaster.h>   /*tf broadcast*/
#include <turtlesim/Pose.h> /*turtlesim*/

std::string turtle_name;    ///string 타입의 변수 생성

void poseCallback(const turtlesim::PoseConstPtr& msg){
    static tf::TransformBroadcaster br; ///static타입의 객체생성
    tf::Transform transform;    ///객체생성
    transform.setOrigin(tf::Vector3(msg->x,msg->y,0.0));    ///msg로 받아온 값들로 matrix설정
    tf::Quaternion q;   ///객체 생성
    q.setRPY(0,0, msg->theta);  ///roll,pitch,yaw 효과 생성
    transform.setRotation(q);   ///rotaion set
    ///생성된 tf형태로 broadcast 실행
    br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "world", turtle_name));
}

int main(int argc, char** argv){
    ros::init(argc,argv, "my_tf_broadcaster");  ///노드를 마스터에 등록
    if(argc !=2){ROS_ERROR("need turtle name as argument"); return -1;};    ///한개의 터틀 사용을 위한 부분
    turtle_name = argv[1];  ///터틀봇 이름 저장
    ros::NodeHandle node;   ///노드 핸들러 생성
    ///Subscriber 생성, topic명 : turtle_name/pose , 버퍼사이즈 : 10, callback함수 : poseCallback 
    ros::Subscriber sub = node.subscribe(turtle_name+"/pose",10,&poseCallback); 
    ros::spin();    ///반복
    return 0;
}

